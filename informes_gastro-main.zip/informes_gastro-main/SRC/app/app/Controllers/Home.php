<?php

namespace App\Controllers;

class Home extends BaseController
{
    public function index(): string
    {
        return view('login');
    }
    public function form(): string
    {
        return view('formulario');
    }
    public function header():string
    {
        return view('header');
    }
}
