# informes_gastro
Sistema web para crear, guardar y enviar por email informes de VEDA o VCC 

Contiene un backend hecho con php y del lado del front html puro por lo pronto
